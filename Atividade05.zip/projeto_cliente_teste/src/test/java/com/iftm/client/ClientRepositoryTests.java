package com.iftm.client;

import com.iftm.client.entities.Client;
import com.iftm.client.repositories.ClientRepository;
import org.apache.tomcat.jni.Local;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;
import java.time.*;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
public class ClientRepositoryTests {

    @Autowired
    private ClientRepository repository;

    @Test
    @DisplayName("Test finding client by name ignoring case")
    public void testFindByNameIgnoreCase() {
        // Testa um nome existente no banco de dados.
        Client result = repository.findByNameIgnoreCase("conceição evaristo");
        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo("Conceição Evaristo");

        // Testa um nome inexistente no banco de dados
        result = repository.findByNameIgnoreCase("João Carlos");
        assertThat(result).isNull();
    }

    @DisplayName("Test findByNameContainingIgnoreCase method")
    @Test
    public void testFindByNameContainingIgnoreCase() {
        // Testando um nome existente
        List<Client> result = repository.findByNameContainingIgnoreCase("ramos");
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getName()).isEqualTo("Lázaro Ramos");

        // Testando um nome inexistente
        result = repository.findByNameContainingIgnoreCase("Gerson Filho");
        assertThat(result).isEmpty();

        // Testando um texto vazio
        result = repository.findByNameContainingIgnoreCase("");
        assertThat(result.size()).isGreaterThanOrEqualTo(1);
    }

    @DisplayName("Test findByIncomeGreaterThan method")
    @Test
    public void testFindByIncomeGreaterThan() {
        // Testa se salário maior que:
        List<Client> result = repository.findByIncomeGreaterThan(5000.0);
        assertNotNull(result);
        assertFalse(result.isEmpty());
        for (Client client : result) {
            assertTrue(client.getIncome() > 5000.0);
        }

        // Testa se salário é menor que:
        result = repository.findByIncomeLessThan(5000.0);
        assertNotNull(result);
        assertFalse(result.isEmpty());
        for (Client client : result) {
            assertTrue(client.getIncome() < 5000.0);
        }

        // Testa se o salário está entre estes dois valores
        result = repository.findByIncomeBetween(3000.0, 7000.0);
        assertNotNull(result);
        assertFalse(result.isEmpty());
        for (Client client : result) {
            assertTrue(client.getIncome() >= 3000.0 && client.getIncome() <= 7000.0);
        }
    }

    @Test
    @DisplayName("Test finding clients with birthdate between two dates")
    public void testFindByBirthdateBetween() {
        LocalDate startDate = LocalDate.parse("2017-12-25");
        LocalDate endDate = LocalDate.now();
        List<Client> result = repository.findByBirthDateBetween(startDate, endDate);
        assertTrue(result.stream().allMatch(c -> {
            LocalDate birthdate = c.getBirthDate().atZone(ZoneOffset.UTC).toLocalDate();
            return birthdate != null && birthdate.isAfter(LocalDate.parse("1979-12-31")) && birthdate.isBefore(LocalDate.now().plusDays(1));
        }));
    }

    @Test
    @DisplayName("Test updating a client")
    public void testUpdateClient() {
        // Retrieve a client from the repository
        Client client = repository.findById(1L).orElseThrow();

        // Update the client's name, income and birthdate
        client.setName("New Name");
        client.setIncome(1000.0);
        client.setBirthDate(Instant.parse("1970-09-23T07:00:00Z"));

        // Save the updated client
        repository.save(client);

        // Retrieve the updated client from the repository
        Client updatedClient = repository.findById(1L).orElseThrow();

        // Verify if the changes were made
        assertEquals("New Name", updatedClient.getName());
        assertEquals(1000.0, updatedClient.getIncome());
        assertEquals(Instant.parse("1970-09-23T07:00:00Z"), updatedClient.getBirthDate());
    }

}